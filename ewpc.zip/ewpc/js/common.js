$('.speaker-carousel').owlCarousel({
    loop:true,
    margin:10,
    autoplay: true,
    nav:true,
    dots: false,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:2
        },
        800:{
            items:3
        },
        1000:{
            items:4
        },
        1200:{
            items:5
        }
    }
})

$('.testimonial-carousel').owlCarousel({
    loop:true,
    margin:10,
    nav: false,
    dots: true,
    autoplay: true,
    responsive:{
        0:{
            items:1
        },
        800:{
            items:2
        }
    }
})
$('.partner-carousel').owlCarousel({
    loop:true,
    margin:10,
    nav: false,
    dots: true,
    autoplay: true,
    responsive:{
        0:{
            items:1
        }
    }
})

$('.blog-carousel').owlCarousel({
    loop:true,
    margin:10,
    autoplay: true,
    nav:true,
    dots: false,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:2
        },
        800:{
            items:3
        }
    }
})